package Task;

import java.util.ArrayList;

public class TaskService {
    // Start with an ArrayList of tasks to hold the list
    public ArrayList<Task> taskList = new ArrayList<Task>();

    // Display the full list of tasks to the console for error checking.
    public void displayTaskList() {
        for (int counter = 0; counter < taskList.size(); counter++) {
            System.out.println("\t Task ID: " + taskList.get(counter).getTaskID());
            System.out.println("\t Task Name: " + taskList.get(counter).getTaskName());
            System.out.println("\t Task Description: " + taskList.get(counter).getTaskDesc());
        }
    }
    // Adds a new task using the Task constructor, then adds it to the list.
    public void addTask(String taskName, String taskDesc) {
        // Create the new task
        Task task = new Task(taskName, taskDesc);
        taskList.add(task);
    }
    // If a matching Task ID is not found, return a task object with default values
    public Task getTask(String taskID) {
        Task task = new Task(null, null);
        for (int counter = 0; counter < taskList.size(); counter++) {
            if (taskList.get(counter).getTaskID().contentEquals(taskID)) {
                task = taskList.get(counter);
            }
        }
        return task;
    }
    // Delete task.
    // Use the taskID to find the right task to delete from the list
    public void deleteTask(String taskID) {
        for (int counter = 0; counter < taskList.size(); counter++) {
            if (taskList.get(counter).getTaskID().equals(taskID)) {
                taskList.remove(counter);
                break;
            }
            if (counter == taskList.size() - 1) {
                System.out.println("Task ID: " + taskID + " not found.");
            }
        }
    }
    // Update the task name.
    public void updateTaskName(String updatedString, String taskID) {
        for (int counter = 0; counter < taskList.size(); counter++) {
            if (taskList.get(counter).getTaskID().equals(taskID)) {
                taskList.get(counter).setTaskName(updatedString);
                break;
            }
            if (counter == taskList.size() - 1) {
                System.out.println("Task ID: " + taskID + " not found.");
            }
        }
    }
    // Update the task description.
    public void updateTaskDesc(String updatedString, String taskID) {
        for (int counter = 0; counter < taskList.size(); counter++) {
            if (taskList.get(counter).getTaskID().equals(taskID)) {
                taskList.get(counter).setTaskDesc(updatedString);
                break;
            }
            if (counter == taskList.size() - 1) {
                System.out.println("Task ID: " + taskID + " not found.");
            }
        }
    }
}
