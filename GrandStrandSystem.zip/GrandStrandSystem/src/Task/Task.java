package Task;

import java.util.concurrent.atomic.AtomicLong;

public class Task {
    private final String taskID;
    private String taskName;
    private String taskDesc;
    private static AtomicLong idGenerator = new AtomicLong();

    // CONSTRUCTOR
    /**
     * @param taskName The name of the task.
     * @param taskDesc The description of the task.
     */
    public Task(String taskName, String taskDesc) {

        // TASKID
        // Task ID is generated when the constructor is called.
        this.taskID = String.valueOf(idGenerator.getAndIncrement());

        if (taskName == null || taskName.isEmpty()) {
            this.taskName = "NULL";
        } else if (taskName.length() > 20) {
            this.taskName = taskName.substring(0, 20);
        } else {
            this.taskName = taskName;
        }

        if (taskDesc == null || taskDesc.isEmpty()) {
            this.taskDesc = "NULL";
        } else if (taskDesc.length() > 50) {
            this.taskDesc = taskDesc.substring(0, 50);
        } else {
            this.taskDesc = taskDesc;
        }
    }

    // Getters
    public String getTaskID() {
        return taskID;
    }

    public String getTaskName() {
        return taskName;
    }

    public String getTaskDesc() {
        return taskDesc;
    }

    // Setters
    /**
     * Sets the name of the task. If the provided name is null or empty, it sets it
     * to "NULL" or max 20 characters.
     */
    public void setTaskName(String taskName) {
        if (taskName == null || taskName.isEmpty()) {
            this.taskName = "NULL";
        } else if (taskName.length() > 20) {
            this.taskName = taskName.substring(0, 20);
        } else {
            this.taskName = taskName;
        }
    }

    /**
     * Sets the description of the task. If the provided description is null or
     * empty, it sets it to "NULL" or max 50 characters.
     */
    public void setTaskDesc(String taskDesc) {
        if (taskDesc == null || taskDesc.isEmpty()) {
            this.taskDesc = "NULL";
        } else if (taskDesc.length() > 50) {
            this.taskDesc = taskDesc.substring(0, 50);
        } else {
            this.taskDesc = taskDesc;
        }
    }
}
