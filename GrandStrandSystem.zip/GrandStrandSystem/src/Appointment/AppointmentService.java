package Appointment;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class AppointmentService {
    private List<Appointment> appointmentList = new ArrayList<>();
    private Set<String> usedAppointmentIDs = new HashSet<>();

    // Display the full list of appointments to the console for error checking.
    public void displayAppointmentList() {
        for (Appointment appointment : appointmentList) {
            System.out.println("\t Appointment ID: " + appointment.getAppointmentID());
            System.out.println("\t Appointment Date: " + appointment.getAppointmentDate());
            System.out.println("\t Appointment Description: " + appointment.getAppointmentDesc());
        }
    }
    // Adds a new appointment with a unique appointmentId.
    public boolean addAppointment(Date appointmentDate, String appointmentDesc) {
        // Check if the appointment date is in the past
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Cannot make appointment before current date.");
        }
        // Generate a unique appointment ID
        String appointmentID = generateUniqueAppointmentID();

        // Create the new appointment
        Appointment appointment = new Appointment(appointmentID, appointmentDate, appointmentDesc);
        appointmentList.add(appointment);
        return true; // Appointment added successfully
    }
    // Delete appointments per appointmentId.
    public boolean deleteAppointment(String appointmentID) {
        Iterator<Appointment> iterator = appointmentList.iterator();
        while (iterator.hasNext()) {
            Appointment appointment = iterator.next();
            if (appointment.getAppointmentID().equals(appointmentID)) {
                iterator.remove();
                usedAppointmentIDs.remove(appointmentID); // Remove ID from used set
                return true; // Appointment deleted successfully
            }
        }
        return false; // Appointment ID not found
    }
    // Helper method to generate a unique appointment ID
    private String generateUniqueAppointmentID() {
        String appointmentID;
        do {
            appointmentID = String.valueOf(System.currentTimeMillis()); // Use timestamp as a unique ID
        } while (usedAppointmentIDs.contains(appointmentID));
        usedAppointmentIDs.add(appointmentID);
        return appointmentID;
    }
}
