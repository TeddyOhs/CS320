package Appointment;

import java.util.concurrent.atomic.AtomicLong;
import java.util.Calendar;
import java.util.Date;

public class Appointment {
    private final String appointmentID;
    private Date appointmentDate;
    private String appointmentDesc;
    private static AtomicLong idGenerator = new AtomicLong();

    // Constructor
    public Appointment(Date appointmentDate, String appointmentDesc) {
        // Generate a unique appointment ID
        this.appointmentID = String.valueOf(idGenerator.getAndIncrement());

        // Set the appointment date with validation
        if (appointmentDate == null) {
            // Default to the current date if null
            this.appointmentDate = new Date();
        } else if (appointmentDate.before(new Date())) {
            // Check if the date is in the past
            throw new IllegalArgumentException("Cannot make appointment before current date.");
        } else {
            this.appointmentDate = appointmentDate;
        }

        // Set the appointment description with length validation
        if (appointmentDesc == null || appointmentDesc.isEmpty()) {
            // Use "NULL" as a placeholder if null or empty
            this.appointmentDesc = "NULL";
        } else if (appointmentDesc.length() > 50) {
            // 50 characters if too long
            this.appointmentDesc = appointmentDesc.substring(0, 50);
        } else {
            this.appointmentDesc = appointmentDesc;
        }
    }
    // Getters
    public String getAppointmentID() {
        return appointmentID;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getAppointmentDesc() {
        return appointmentDesc;
    }
    // Setter for appointment date
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null) {
            // Default to the current date if null
            this.appointmentDate = new Date();
        } else if (appointmentDate.before(new Date())) {
            // Check if the date is in the past
            throw new IllegalArgumentException("Cannot make appointment before current date.");
        } else {
            this.appointmentDate = appointmentDate;
        }
    }
    // Setter for appointment description
    public void setAppointmentDesc(String appointmentDesc) {
        if (appointmentDesc == null || appointmentDesc.isEmpty()) {
            // Use "NULL" as a placeholder if null or empty
            this.appointmentDesc = "NULL";
        } else if (appointmentDesc.length() > 50) {
            // Truncate to 50 characters if too long
            this.appointmentDesc = appointmentDesc.substring(0, 50);
        } else {
            this.appointmentDesc = appointmentDesc;
        }
    }
}
