package Test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

import Contact.Contact;
import Contact.ContactService;

import org.junit.jupiter.api.Order;

@TestMethodOrder(OrderAnnotation.class)
public class ContactServiceTest {

    @Test
    @DisplayName("Test to Update First Name")
    void testUpdateFirstName() {
        // Arrange
        ContactService service = new ContactService();
        service.addContact("Mr.", "Smith", "5555551111", "123 Boardwalk Street");

        // Act
        service.updateFirstName("Otto", "0");

        // Assert
        service.displayContactList();
        assertEquals("Otto", service.getContact("0").getFirstName(), "First name was not updated.");
    }

    @Test
    @DisplayName("Test to Update Last Name")
    void testUpdateLastName() {
        // Arrange
        ContactService service = new ContactService();
        service.addContact("Mr.", "Smith", "5555551111", "123 Boardwalk Street");

        // Act
        service.updateLastName("Matt", "1");

        // Assert
        service.displayContactList();
        assertEquals("Matt", service.getContact("1").getLastName(), "Last name was not updated.");
    }

    @Test
    @DisplayName("Test to update phone number")
    void testUpdatePhoneNumber() {
        // Arrange
        ContactService service = new ContactService();
        service.addContact("Mr.", "Smith", "5555551111", "123 Boardwalk Street");

        // Act
        service.updateNumber("5555550000", "2");

        // Assert
        service.displayContactList();
        assertEquals("5555550000", service.getContact("2").getNumber(), "Phone number was not updated.");
    }

    @Test
    @DisplayName("Test to update address")
    void testUpdateAddress() {
        // Arrange
        ContactService service = new ContactService();
        service.addContact("Mr.", "Smith", "5555551111", "123 Boardwalk Street");

        // Act
        service.updateAddress("555 Nowhere Ave", "3");

        // Assert
        service.displayContactList();
        assertEquals("555 Nowhere Ave", service.getContact("3").getAddress(), "Address was not updated.");
    }

    @Test
    @DisplayName("Test to ensure that service correctly deletes contacts")
    void testDeleteContact() {
        // Arrange
        ContactService service = new ContactService();
        service.addContact("Mr.", "Smith", "5555551111", "123 Boardwalk Street");

        // Act
        service.deleteContact("4");

        // Assert
        // Ensure that the contactList is now empty
        ArrayList<Contact> contactListEmpty = new ArrayList<Contact>();
        service.displayContactList();
        assertEquals(contactListEmpty, service.contactList, "The contact was not deleted.");
    }

    @Test
    @DisplayName("Test to ensure that service can add a contact")
    void testAddContact() {
        // Arrange
        ContactService service = new ContactService();
        service.addContact("Mr.", "Smith", "5555551111", "123 Boardwalk Street");

        // Act & Assert
        service.displayContactList();
        assertNotNull(service.getContact("5"), "Contact was not added correctly.");
    }
}
