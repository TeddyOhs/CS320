package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;

class AppointmentTest {

    // Helper method to create a Date object with the current time
    private Date getCurrentDate() {
        return new Date();
    }

    @Test
    @DisplayName("Appointment ID cannot have more than 10 characters")
    void testAppointmentIDWithMoreThanTenCharacters() {
        Appointment appointment = new Appointment(getCurrentDate(), "Description");
        if (appointment.getAppointmentID().length() > 10) {
            fail("Appointment ID has more than 10 characters.");
        }
    }

    @Test
    @DisplayName("Task Description cannot have more than 50 characters")
    void testAppointmentDescWithMoreThanFiftyCharacters() {
        String longDescription = "123456789 is nine characters long"
                + "123456789 is another nine characters long"
                + "123456789 is another nine characters long"
                + "123456789 is another nine characters long";
        Appointment appointment = new Appointment(getCurrentDate(), longDescription);
        if (appointment.getAppointmentDesc().length() > 50) {
            fail("Appointment Description has more than 50 characters.");
        }
    }

    @Test
    @DisplayName("Appointment Date cannot be before current date")
    void testAppointmentDateBeforeCurrent() {
        Calendar pastCalendar = Calendar.getInstance();
        pastCalendar.set(2022, Calendar.JANUARY, 1); // A date in the past (January 1, 2022)
        Date pastDate = pastCalendar.getTime();
        Appointment appointment = new Appointment(pastDate, "Description");
        if (appointment.getAppointmentDate().before(getCurrentDate())) {
            fail("Appointment Date is before the current date.");
        }
    }

    @Test
    @DisplayName("Task Date shall not be null")
    void testAppointmentDateNotNull() {
        Appointment appointment = new Appointment(null, "Description");
        assertNotNull(appointment.getAppointmentDate(), "Appointment Date was null.");
    }

    @Test
    @DisplayName("Task Description shall not be null")
    void testAppointmentDescNotNull() {
        Appointment appointment = new Appointment(getCurrentDate(), null);
        assertNotNull(appointment.getAppointmentDesc(), "Appointment Description was null.");
    }
}
