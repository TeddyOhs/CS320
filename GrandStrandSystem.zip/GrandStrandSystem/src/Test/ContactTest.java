package Test;

import org.junit.jupiter.api.Test;
import Contact.Contact;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    @DisplayName("Contact ID cannot have more than 10 characters")
    void testContactIDWithMoreThanTenCharacters() {
        Contact contact = new Contact("FirstName", "LastName", "PhoneNumber", "Address");
        if (contact.getContactID().length() > 10) {
            fail("Contact ID has more than 10 characters.");
        }
    }

    @Test
    @DisplayName("Contact First Name cannot have more than 10 characters")
    void testContactFirstNameWithMoreThanTenCharacters() {
        Contact contact = new Contact("Otto", "LastName", "PhoneNumber", "Address");
        if (contact.getFirstName().length() > 10) {
            fail("First Name has more than 10 characters.");
        }
    }

    @Test
    @DisplayName("Contact Last Name cannot have more than 10 characters")
    void testContactLastNameWithMoreThanTenCharacters() {
        Contact contact = new Contact("FirstName", "Otto", "PhoneNumber", "Address");
        if (contact.getLastName().length() > 10) {
            fail("Last Name has more than 10 characters.");
        }
    }

    @Test
    @DisplayName("Contact phone number is exactly 10 characters")
    void testContactNumberWithMoreThanTenCharacters() {
        Contact contact = new Contact("FirstName", "LastName", "5555555555", "Address");
        if (contact.getNumber().length() != 10) {
            fail("Phone number invalid");
        }
    }

    @Test
    @DisplayName("Contact address cannot have more than 30 characters")
    void testContactAddressWithMoreThanThirtyCharacters() {
        Contact contact = new Contact("FirstName", "LastName", "PhoneNumber",
                "123456789 is nine characters long" + "123456789 is another nine characters long");
        if (contact.getAddress().length() > 30) {
            fail("Address has more than 30 characters.");
        }
    }

    @Test
    @DisplayName("Contact First Name shall not be null")
    void testContactFirstNameNotNull() {
        Contact contact = new Contact(null, "LastName", "PhoneNumber", "Address");
        assertNotNull(contact.getFirstName(), "First name was null.");
    }

    @Test
    @DisplayName("Contact Last Name shall not be null")
    void testContactLastNameNotNull() {
        Contact contact = new Contact("FirstName", null, "PhoneNumber", "Address");
        assertNotNull(contact.getLastName(), "Last name was null.");
    }

    @Test
    @DisplayName("Contact Phone Number shall not be null")
    void testContactPhoneNotNull() {
        Contact contact = new Contact("FirstName", "LastName", null, "Address");
        assertNotNull(contact.getNumber(), "Phone number was null.");
    }

    @Test
    @DisplayName("Contact Address shall not be null")
    void testContactAddressNotNull() {
        Contact contact = new Contact("FirstName", "LastName", "PhoneNumber", null);
        assertNotNull(contact.getAddress(), "Address was null.");
    }

    @Test
    @DisplayName("Test to ensure that two contacts with the same data have different IDs")
    void testContactIDsAreUnique() {
        Contact contact1 = new Contact("Alice", "Johnson", "5555551234", "123 Main St");
        Contact contact2 = new Contact("Alice", "Johnson", "5555551234", "123 Main St");

        assertNotEquals(contact1.getContactID(), contact2.getContactID(), "Contact IDs are not unique.");
    }

    @Test
    @DisplayName("Test to ensure that contact creation sets the fields correctly")
    void testContactCreationSetsFields() {
        Contact contact = new Contact("John", "Smith", "5555556789", "456 Elm St");

        assertEquals("John", contact.getFirstName(), "First name was not set correctly.");
        assertEquals("Smith", contact.getLastName(), "Last name was not set correctly.");
        assertEquals("5555556789", contact.getNumber(), "Phone number was not set correctly.");
        assertEquals("456 Elm St", contact.getAddress(), "Address was not set correctly.");
    }
}
