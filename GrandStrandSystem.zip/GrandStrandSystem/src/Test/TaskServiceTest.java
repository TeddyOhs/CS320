package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Task.Task;
import Task.TaskService;

class TaskServiceTest {
    @Test
    @DisplayName("Test to ensure that service can add a task.")
    void testAddTask() {
        TaskService service = new TaskService();
        Task task = service.addTask("Task Name", "Description");
        service.displayTaskList();
        assertNotNull(task, "Task was not added correctly.");
    }

    @Test
    @DisplayName("Test to Update task name")
    void testUpdateTaskName() {
        TaskService service = new TaskService();
        Task task = service.addTask("Task Name", "Description");
        service.updateTaskName(task.getTaskID(), "Updated Task Name");
        service.displayTaskList();
        assertEquals("Updated Task Name", service.getTask(task.getTaskID()).getTaskName(), "Task name was not updated.");
    }

    @Test
    @DisplayName("Test to Update task description.")
    void testUpdateTaskDesc() {
        TaskService service = new TaskService();
        Task task = service.addTask("Task Name", "Description");
        service.updateTaskDesc(task.getTaskID(), "Updated Description");
        service.displayTaskList();
        assertEquals("Updated Description", service.getTask(task.getTaskID()).getTaskDesc(), "Task description was not updated.");
    }

    @Test
    @DisplayName("Test to ensure that service correctly deletes tasks.")
    void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = service.addTask("Task Name", "Description");
        service.deleteTask(task.getTaskID());
        // Ensure that the taskList is now empty by creating a new empty taskList to compare it with
        ArrayList<Task> taskListEmpty = new ArrayList<Task>();
        service.displayTaskList();
        assertEquals(taskListEmpty, service.getTaskList(), "The task was not deleted.");
    }

    @Test
    @DisplayName("Test to ensure that task IDs are unique.")
    void testTaskIDsAreUnique() {
        TaskService service = new TaskService();
        Task task1 = service.addTask("Task 1", "Description 1");
        Task task2 = service.addTask("Task 2", "Description 2");

        assertNotEquals(task1.getTaskID(), task2.getTaskID(), "Task IDs are not unique.");
    }
}
