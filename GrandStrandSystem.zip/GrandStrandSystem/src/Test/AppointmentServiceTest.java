package Test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import Appointment.AppointmentService;

class AppointmentServiceTest {
    
    private Date getCurrentDate() {
        Calendar calendar = Calendar.getInstance();
        return calendar.getTime();
    }

    @Test
    @DisplayName("Test adding a new appointment")
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date appointmentDate = getCurrentDate(); // Get the current date
        service.addAppointment(appointmentDate, "Description");
        // Check if the added appointment's date and description match the expected values
        assertEquals(appointmentDate, service.getAppointment("1").getAppointmentDate());
        assertEquals("Description", service.getAppointment("1").getAppointmentDesc());
    }

    @Test
    @DisplayName("Test updating appointment date")
    void testUpdateAppointmentDate() {
        AppointmentService service = new AppointmentService();
        Date originalDate = getCurrentDate(); // Get the current date
        service.addAppointment(originalDate, "Description");
        
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1); // Add one day to the current date
        Date updatedDate = calendar.getTime();
        
        service.updateAppointmentDate(updatedDate, "1");
        assertEquals(updatedDate, service.getAppointment("1").getAppointmentDate());
    }

    @Test
    @DisplayName("Test updating appointment description")
    void testUpdateAppointmentDesc() {
        AppointmentService service = new AppointmentService();
        Date appointmentDate = getCurrentDate(); // Get the current date
        service.addAppointment(appointmentDate, "Description");
        
        service.updateAppointmentDesc("Updated Description", "1");
        
        // Check if the appointment's description was updated correctly
        assertEquals("Updated Description", service.getAppointment("1").getAppointmentDesc());
    }

    @Test
    @DisplayName("Test deleting an appointment")
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date appointmentDate = getCurrentDate(); // Get the current date
        service.addAppointment(appointmentDate, "Description");
        
        service.deleteAppointment("1");
        
        // Check if the appointment was deleted (should return null)
        assertNull(service.getAppointment("1"));
    }

    @Test
    @DisplayName("Test deleting a non-existing appointment")
    void testDeleteNonExistingAppointment() {
        AppointmentService service = new AppointmentService();
        
        // Delete an appointment that doesn't exist
        service.deleteAppointment("1");
        
        // Ensure no errors are thrown
        assertNull(service.getAppointment("1"));
    }
}
